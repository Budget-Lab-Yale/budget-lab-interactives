---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through June 16"
  originalSheet: "T1"
  vintageDate: "2025-06-17"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through June 16**
