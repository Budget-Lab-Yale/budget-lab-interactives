---
figureType: table
spec:
  title: "Appendix: Comparison of 2027 Distributional Effects of 2025 Tariffs to Date"
  subtitle: "Through June 16. By household income decile"
  source: "GTAP v7, Census, BLS, BEA, The Budget Lab analysis."
  originalSheet: "A1"
  vintageDate: "2025-06-17"
---

**Appendix: Comparison of 2027 Distributional Effects of 2025 Tariffs to Date**

Through June 16. By household income decile

_Source: GTAP v7, Census, BLS, BEA, The Budget Lab analysis._
