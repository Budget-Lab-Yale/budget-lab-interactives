---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through July 13"
  originalSheet: "T1"
  vintageDate: "2025-07-13"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through July 13**
