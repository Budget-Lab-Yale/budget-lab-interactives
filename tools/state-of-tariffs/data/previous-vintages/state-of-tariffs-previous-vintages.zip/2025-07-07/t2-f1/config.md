---
figureType: table
spec:
  title: "Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy Through July 7"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "T2,F1"
  vintageDate: "2025-07-07"
---

**Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy Through July 7**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
