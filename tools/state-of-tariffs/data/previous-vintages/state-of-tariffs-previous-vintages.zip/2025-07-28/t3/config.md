---
figureType: table
spec:
  title: "Table 3. Estimated Revenue Effects of All 2025 Tariffs"
  subtitle: "Through July 27."
  source: "Congressional Budget Office, GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  originalSheet: "T3"
  vintageDate: "2025-07-28"
---

**Table 3. Estimated Revenue Effects of All 2025 Tariffs**

Through July 27.

_Source: Congressional Budget Office, GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
