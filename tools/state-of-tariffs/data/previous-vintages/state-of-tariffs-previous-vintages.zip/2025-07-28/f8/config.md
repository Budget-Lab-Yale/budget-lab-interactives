---
figureType: table
spec:
  title: "Figure 8. Commodity Price Effects from 2025 Tariffs Through July 27"
  subtitle: "Percent change to price level"
  source: "GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "'nec' = 'Not elsewhere classified.'"
  originalSheet: "F8"
  vintageDate: "2025-07-28"
---

**Figure 8. Commodity Price Effects from 2025 Tariffs Through July 27**

Percent change to price level

_Notes: "nec" = "Not elsewhere classified."_

_Source: GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
