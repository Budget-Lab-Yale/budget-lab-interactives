---
figureType: table
spec:
  title: "Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy Through July 27"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "F2_T2"
  vintageDate: "2025-07-28"
---

**Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy Through July 27**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
