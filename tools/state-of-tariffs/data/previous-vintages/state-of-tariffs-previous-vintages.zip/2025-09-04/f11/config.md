---
figureType: table
spec:
  title: "Figure 11. U.S Average Effective Tariff Rate Since January 1, 2025, No IEEPA"
  subtitle: "Policy as of September 3, Pre-Substitution, Percent of goods imports."
  source: "The Budget Lab analysis."
  originalSheet: "F11"
  vintageDate: "2025-09-04"
---

**Figure 11. U.S Average Effective Tariff Rate Since January 1, 2025, No IEEPA**

Policy as of September 3, Pre-Substitution, Percent of goods imports.

_Source: The Budget Lab analysis._
