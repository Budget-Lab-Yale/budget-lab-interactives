---
figureType: table
spec:
  title: "Figure 16. Commodity Price Effects from 2025 Tariffs as of September 3, No IEEPA"
  subtitle: "Percent change to price level."
  source: "GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "'nec' = 'Not elsewhere classified.'"
  originalSheet: "F16"
  vintageDate: "2025-09-04"
---

**Figure 16. Commodity Price Effects from 2025 Tariffs as of September 3, No IEEPA**

Percent change to price level.

_Notes: "nec" = "Not elsewhere classified."_

_Source: GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
