---
figureType: table
spec:
  title: "Table 3. Estimated Revenue Effects of All 2025 Tariffs"
  subtitle: "As of September 3."
  source: "Congressional Budget Office, GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  originalSheet: "T3"
  vintageDate: "2025-09-04"
---

**Table 3. Estimated Revenue Effects of All 2025 Tariffs**

As of September 3.

_Source: Congressional Budget Office, GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
