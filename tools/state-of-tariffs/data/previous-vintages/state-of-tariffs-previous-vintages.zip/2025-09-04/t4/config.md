---
figureType: table
spec:
  title: "Table 4. Summary Economic & Fiscal Effects of 2025 Tariffs as of September 3, No IEEPA"
  originalSheet: "T4"
  vintageDate: "2025-09-04"
---

**Table 4. Summary Economic & Fiscal Effects of 2025 Tariffs as of September 3, No IEEPA**
