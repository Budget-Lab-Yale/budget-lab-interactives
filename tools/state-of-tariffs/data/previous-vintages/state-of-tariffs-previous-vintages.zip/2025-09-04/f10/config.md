---
figureType: table
spec:
  title: "Figure 10. U.S. Average Effective Tariff Rate Since 1790, No IEEPA"
  subtitle: "Customs duty revenue as a percentage of goods imports."
  source: "Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis."
  originalSheet: "F10"
  vintageDate: "2025-09-04"
---

**Figure 10. U.S. Average Effective Tariff Rate Since 1790, No IEEPA**

Customs duty revenue as a percentage of goods imports.

_Source: Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis._
