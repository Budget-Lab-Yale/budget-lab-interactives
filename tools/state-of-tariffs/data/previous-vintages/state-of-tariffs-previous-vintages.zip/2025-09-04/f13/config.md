---
figureType: table
spec:
  title: "Figure 13. Change in Long-Run Real U.S. GDP by Sector from 2025 Tariffs, No IEEPA"
  subtitle: "U.S. tariffs implemented as of September 3, plus foreign retaliation. Percentage points."
  source: "GTAP v7, The Budget Lab analysis."
  notes: "Real value added by sector."
  originalSheet: "F13"
  vintageDate: "2025-09-04"
---

**Figure 13. Change in Long-Run Real U.S. GDP by Sector from 2025 Tariffs, No IEEPA**

U.S. tariffs implemented as of September 3, plus foreign retaliation. Percentage points.

_Notes: Real value added by sector._

_Source: GTAP v7, The Budget Lab analysis._
