---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs as of September 3"
  originalSheet: "T1"
  vintageDate: "2025-09-04"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs as of September 3**
