---
figureType: table
spec:
  title: "Table 5/Figure 9. Average Effective US Tariff Rate, New 2025 Policy as of September 3, No IEEPA"
  subtitle: "Pre- and post-substitution."
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "T5,F9"
  vintageDate: "2025-09-04"
---

**Table 5/Figure 9. Average Effective US Tariff Rate, New 2025 Policy as of September 3, No IEEPA**

Pre- and post-substitution.

_Source: GTAP v7, The Budget Lab analysis._
