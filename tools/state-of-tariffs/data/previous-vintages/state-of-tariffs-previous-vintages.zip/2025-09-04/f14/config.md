---
figureType: table
spec:
  title: "Figure 14. Long-Run Change in Real GDP Level from 2025 Tariffs to Date, No IEEPA"
  subtitle: "U.S. tariffs implemented as of September 3. Percentage point change."
  source: "GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "FTROW = countries with a comprehensive free trade agreement with the US. ROW = all other countries."
  originalSheet: "F14"
  vintageDate: "2025-09-04"
---

**Figure 14. Long-Run Change in Real GDP Level from 2025 Tariffs to Date, No IEEPA**

U.S. tariffs implemented as of September 3. Percentage point change.

_Notes: FTROW = countries with a comprehensive free trade agreement with the US. ROW = all other countries._

_Source: GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
