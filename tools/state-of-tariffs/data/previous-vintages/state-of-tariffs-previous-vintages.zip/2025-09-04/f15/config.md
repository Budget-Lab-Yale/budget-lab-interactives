---
figureType: table
spec:
  title: "Figure 15. Short-Run Distributional Impact of 2025 Tariffs to Date, No IEEPA"
  subtitle: "As of September 3. By household income decile."
  source: "GTAP v7, Census, BLS, BEA, The Budget Lab analysis."
  originalSheet: "F15"
  vintageDate: "2025-09-04"
---

**Figure 15. Short-Run Distributional Impact of 2025 Tariffs to Date, No IEEPA**

As of September 3. By household income decile.

_Source: GTAP v7, Census, BLS, BEA, The Budget Lab analysis._
