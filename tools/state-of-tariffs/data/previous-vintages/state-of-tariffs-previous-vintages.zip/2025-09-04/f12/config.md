---
figureType: table
spec:
  title: "Figure 12. U.S. Real GDP Level Effects of 2025 Tariffs to Date, No IEEPA"
  subtitle: "US tariffs implemented as of September 3. Percentage point change against baseline."
  source: "Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis."
  originalSheet: "F12"
  vintageDate: "2025-09-04"
---

**Figure 12. U.S. Real GDP Level Effects of 2025 Tariffs to Date, No IEEPA**

US tariffs implemented as of September 3. Percentage point change against baseline.

_Source: Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis._
