---
figureType: table
spec:
  title: "Appendix Table 3. Estimated Revenue Effects of All 2025 Tariffs, IEEPA Invalidation Scenario"
  subtitle: "Through October 30."
  source: "Congressional Budget Office, GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "Excludes effects of IEEPA collections or refunds"
  originalSheet: "AT3"
  vintageDate: "2025-10-30"
---

**Appendix Table 3. Estimated Revenue Effects of All 2025 Tariffs, IEEPA Invalidation Scenario**

Through October 30.

_Notes: Excludes effects of IEEPA collections or refunds_

_Source: Congressional Budget Office, GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
