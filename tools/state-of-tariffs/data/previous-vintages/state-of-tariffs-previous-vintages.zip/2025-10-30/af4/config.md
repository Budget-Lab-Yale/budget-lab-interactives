---
figureType: table
spec:
  title: "Appendix Figure 4. US Real GDP Level Effects of 2025 Tariffs to Date, IEEPA Invalidation Scenario"
  subtitle: "US tariffs implemented through October 30. Percentage point change against baseline"
  source: "Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis."
  originalSheet: "AF4"
  vintageDate: "2025-10-30"
---

**Appendix Figure 4. US Real GDP Level Effects of 2025 Tariffs to Date, IEEPA Invalidation Scenario**

US tariffs implemented through October 30. Percentage point change against baseline

_Source: Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis._
