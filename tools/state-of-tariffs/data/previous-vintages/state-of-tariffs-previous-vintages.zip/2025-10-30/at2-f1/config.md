---
figureType: table
spec:
  title: "Appendix Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy through October 30, IEEPA Invalidation Scenario"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "AT2,F1"
  vintageDate: "2025-10-30"
---

**Appendix Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy through October 30, IEEPA Invalidation Scenario**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
