---
figureType: table
spec:
  title: "Appendix Figure 6. Long-Run Change in Real GDP Level from 2025 Tariffs to Date, IEEPA Invalidation Scenario"
  subtitle: "U.S. tariffs implemented through October 30. Percentage point change"
  source: "GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "FTROW = countries with a comprehensive free trade agreement with the US. ROW = all other countries."
  originalSheet: "AF6"
  vintageDate: "2025-10-30"
---

**Appendix Figure 6. Long-Run Change in Real GDP Level from 2025 Tariffs to Date, IEEPA Invalidation Scenario**

U.S. tariffs implemented through October 30. Percentage point change

_Notes: FTROW = countries with a comprehensive free trade agreement with the US. ROW = all other countries._

_Source: GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
