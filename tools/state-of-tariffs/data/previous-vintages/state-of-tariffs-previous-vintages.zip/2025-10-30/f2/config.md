---
figureType: table
spec:
  title: "Figure 2. US Average Effective Tariff Rate Since 1790"
  subtitle: "Customs duty revenue as a percentage of goods imports"
  source: "Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis."
  originalSheet: "F2"
  vintageDate: "2025-10-30"
---

**Figure 2. US Average Effective Tariff Rate Since 1790**

Customs duty revenue as a percentage of goods imports

_Source: Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis._
