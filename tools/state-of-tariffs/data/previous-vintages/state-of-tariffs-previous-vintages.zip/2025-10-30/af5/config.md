---
figureType: table
spec:
  title: "Appendix Figure 5. Change in Long-Run Real US GDP by Sector from 2025 Tariffs, IEEPA Invalidation Scenario"
  subtitle: "U.S. tariffs implemented through October 30, plus foreign retaliation. Percentage points."
  source: "GTAP v7, The Budget Lab analysis."
  notes: "Real value added by sector."
  originalSheet: "AF5"
  vintageDate: "2025-10-30"
---

**Appendix Figure 5. Change in Long-Run Real US GDP by Sector from 2025 Tariffs, IEEPA Invalidation Scenario**

U.S. tariffs implemented through October 30, plus foreign retaliation. Percentage points.

_Notes: Real value added by sector._

_Source: GTAP v7, The Budget Lab analysis._
