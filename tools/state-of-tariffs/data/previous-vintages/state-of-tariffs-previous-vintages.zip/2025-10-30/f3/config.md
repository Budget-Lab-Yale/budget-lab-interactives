---
figureType: table
spec:
  title: "Figure 3. US Average Effective Tariff Rate Since January 1, 2025"
  subtitle: "Policy through October 30, Pre-Substitution, Percent of goods imports"
  source: "The Budget Lab analysis."
  notes: "TBL's method for calculating effective tariff rates (ETR) changed slightly on October 30. All else equal this change leads to a 0.9pp increase in the ETR. Values prior to October 30 do not reflect this change."
  originalSheet: "F3"
  vintageDate: "2025-10-30"
---

**Figure 3. US Average Effective Tariff Rate Since January 1, 2025**

Policy through October 30, Pre-Substitution, Percent of goods imports

_Notes: TBL's method for calculating effective tariff rates (ETR) changed slightly on October 30. All else equal this change leads to a 0.9pp increase in the ETR. Values prior to October 30 do not reflect this change._

_Source: The Budget Lab analysis._
