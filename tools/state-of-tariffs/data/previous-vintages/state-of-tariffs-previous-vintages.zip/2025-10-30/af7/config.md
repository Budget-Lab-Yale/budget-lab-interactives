---
figureType: table
spec:
  title: "Appendix Figure 7. Short-Run Distributional Effects of 2025 Tariffs, IEEPA Invalidation Scenario"
  subtitle: "Through October 30. By household income decile"
  source: "GTAP v7, Census, BLS, BEA, The Budget Lab analysis."
  originalSheet: "AF7"
  vintageDate: "2025-10-30"
---

**Appendix Figure 7. Short-Run Distributional Effects of 2025 Tariffs, IEEPA Invalidation Scenario**

Through October 30. By household income decile

_Source: GTAP v7, Census, BLS, BEA, The Budget Lab analysis._
