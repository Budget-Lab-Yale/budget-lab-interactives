---
figureType: table
spec:
  title: "Table 3. Estimated Revenue Effects of All 2025 Tariffs"
  subtitle: "Through October 30."
  source: "Congressional Budget Office, GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  originalSheet: "T3"
  vintageDate: "2025-10-30"
---

**Table 3. Estimated Revenue Effects of All 2025 Tariffs**

Through October 30.

_Source: Congressional Budget Office, GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
