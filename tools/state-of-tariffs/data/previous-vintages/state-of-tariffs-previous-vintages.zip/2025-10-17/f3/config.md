---
figureType: table
spec:
  title: "Figure 3. US Average Effective Tariff Rate Since January 1, 2025"
  subtitle: "Policy through October 17, Pre-Substitution, Percent of goods imports"
  source: "The Budget Lab analysis."
  originalSheet: "F3"
  vintageDate: "2025-10-17"
---

**Figure 3. US Average Effective Tariff Rate Since January 1, 2025**

Policy through October 17, Pre-Substitution, Percent of goods imports

_Source: The Budget Lab analysis._
