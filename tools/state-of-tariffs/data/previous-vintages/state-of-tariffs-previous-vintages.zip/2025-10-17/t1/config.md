---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs through October 17"
  originalSheet: "T1"
  vintageDate: "2025-10-17"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs through October 17**
