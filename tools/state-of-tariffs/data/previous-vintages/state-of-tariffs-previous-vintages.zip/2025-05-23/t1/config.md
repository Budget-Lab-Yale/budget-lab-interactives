---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through May 23"
  originalSheet: "T1"
  vintageDate: "2025-05-23"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through May 23**
