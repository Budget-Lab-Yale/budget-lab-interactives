---
figureType: table
spec:
  title: "Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy Through May 23"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "T2,F1"
  vintageDate: "2025-05-23"
---

**Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy Through May 23**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
