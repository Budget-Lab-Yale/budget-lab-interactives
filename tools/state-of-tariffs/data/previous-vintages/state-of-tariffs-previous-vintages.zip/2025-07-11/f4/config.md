---
figureType: table
spec:
  title: "Figure 4. Change in Long-Run Real US GDP by Sector from 2025 Tariffs"
  subtitle: "U.S. tariffs implemented through July 11, plus foreign retaliation. Percentage points."
  source: "GTAP v7, The Budget Lab analysis."
  notes: "Real value added by sector."
  originalSheet: "F4"
  vintageDate: "2025-07-11"
---

**Figure 4. Change in Long-Run Real US GDP by Sector from 2025 Tariffs**

U.S. tariffs implemented through July 11, plus foreign retaliation. Percentage points.

_Notes: Real value added by sector._

_Source: GTAP v7, The Budget Lab analysis._
