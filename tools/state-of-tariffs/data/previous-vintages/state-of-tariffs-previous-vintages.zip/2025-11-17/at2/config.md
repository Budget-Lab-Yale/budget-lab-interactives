---
figureType: table
spec:
  title: "Appendix Table 2. Average Effective US Tariff Rate, New 2025 Policy through November 17, IEEPA Invalidation Scenario"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "AT2"
  vintageDate: "2025-11-17"
---

**Appendix Table 2. Average Effective US Tariff Rate, New 2025 Policy through November 17, IEEPA Invalidation Scenario**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
