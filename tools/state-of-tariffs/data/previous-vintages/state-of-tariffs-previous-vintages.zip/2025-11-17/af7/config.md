---
figureType: table
spec:
  title: "Appendix Figure 7. Commodity Price Effects from 2025 Tariffs through November 17, IEEPA Invalidation Scenario"
  subtitle: "Percent change to price level"
  source: "GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "'nec' = 'Not elsewhere classified.'"
  originalSheet: "AF7"
  vintageDate: "2025-11-17"
---

**Appendix Figure 7. Commodity Price Effects from 2025 Tariffs through November 17, IEEPA Invalidation Scenario**

Percent change to price level

_Notes: "nec" = "Not elsewhere classified."_

_Source: GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
