---
figureType: table
spec:
  title: "Appendix Figure 6. Short-Run Distributional Effects of 2025 Tariffs, IEEPA Invalidation Scenario"
  subtitle: "Through November 17. By household income decile"
  source: "GTAP v7, Census, BLS, BEA, The Budget Lab analysis."
  originalSheet: "AF6"
  vintageDate: "2025-11-17"
---

**Appendix Figure 6. Short-Run Distributional Effects of 2025 Tariffs, IEEPA Invalidation Scenario**

Through November 17. By household income decile

_Source: GTAP v7, Census, BLS, BEA, The Budget Lab analysis._
