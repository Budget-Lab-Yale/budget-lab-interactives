---
figureType: table
spec:
  title: "Appendix Figure 3. US Real GDP Level Effects of 2025 Tariffs to Date, IEEPA Invalidation Scenario"
  subtitle: "US tariffs implemented through November 17. Percentage point change against baseline"
  source: "Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis."
  originalSheet: "AF3"
  vintageDate: "2025-11-17"
---

**Appendix Figure 3. US Real GDP Level Effects of 2025 Tariffs to Date, IEEPA Invalidation Scenario**

US tariffs implemented through November 17. Percentage point change against baseline

_Source: Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis._
