---
figureType: table
spec:
  title: "Table 2. Average Effective US Tariff Rate, New 2025 Policy through November 17"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "T2"
  vintageDate: "2025-11-17"
---

**Table 2. Average Effective US Tariff Rate, New 2025 Policy through November 17**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
