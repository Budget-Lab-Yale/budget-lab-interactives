---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through July 9"
  originalSheet: "T1"
  vintageDate: "2025-07-10"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through July 9**
