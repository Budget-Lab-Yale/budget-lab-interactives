---
figureType: table
spec:
  title: "Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy Through July 9"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "T2,F1"
  vintageDate: "2025-07-10"
---

**Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy Through July 9**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
