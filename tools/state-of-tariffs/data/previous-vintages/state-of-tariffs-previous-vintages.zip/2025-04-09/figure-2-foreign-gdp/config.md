---
figureType: table
spec:
  originalSheet: "Figure 2 Foreign GDP"
  vintageDate: "2025-04-09"
---
