---
figureType: table
spec:
  originalSheet: "Figure 1 GDP"
  vintageDate: "2025-04-09"
---
