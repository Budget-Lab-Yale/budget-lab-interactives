---
figureType: table
spec:
  title: "Summary Economic & Fiscal Effects of 2025 Tariffs Through April 9"
  originalSheet: "Summary Table"
  vintageDate: "2025-04-09"
---

**Summary Economic & Fiscal Effects of 2025 Tariffs Through April 9**
