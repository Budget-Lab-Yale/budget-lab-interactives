---
figureType: table
spec:
  title: "1790"
  originalSheet: "Figure 3 Historical"
  vintageDate: "2025-04-09"
---

**1790**
