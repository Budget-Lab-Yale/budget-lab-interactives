---
figureType: table
spec:
  title: "Average Effective US Tariff Rate, New 2025 Policy Through April 9"
  originalSheet: "Table 1 "
  vintageDate: "2025-04-09"
---

**Average Effective US Tariff Rate, New 2025 Policy Through April 9**
