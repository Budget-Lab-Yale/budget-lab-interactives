---
figureType: table
spec:
  title: "% OF ATI"
  originalSheet: "Figure 4 Distribution"
  vintageDate: "2025-04-09"
---

**% OF ATI**
