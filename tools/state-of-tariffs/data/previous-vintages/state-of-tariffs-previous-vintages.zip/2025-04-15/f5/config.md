---
figureType: table
spec:
  title: "Figure 5. Short-Run Distributional Effects of 2025 Tariffs"
  subtitle: "Through April 15. By household income decile"
  source: "GTAP v7, Census, BLS, BEA, The Budget Lab analysis."
  originalSheet: "F5"
  vintageDate: "2025-04-15"
---

**Figure 5. Short-Run Distributional Effects of 2025 Tariffs**

Through April 15. By household income decile

_Source: GTAP v7, Census, BLS, BEA, The Budget Lab analysis._
