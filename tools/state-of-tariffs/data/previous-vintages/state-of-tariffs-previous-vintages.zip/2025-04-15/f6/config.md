---
figureType: table
spec:
  title: "Figure 6. Commodity Price Effects from 2025 Tariffs Through April 15"
  subtitle: "Percent change to price level"
  source: "GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "'nec' = 'Not elsewhere classified.'"
  originalSheet: "F6"
  vintageDate: "2025-04-15"
---

**Figure 6. Commodity Price Effects from 2025 Tariffs Through April 15**

Percent change to price level

_Notes: "nec" = "Not elsewhere classified."_

_Source: GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
