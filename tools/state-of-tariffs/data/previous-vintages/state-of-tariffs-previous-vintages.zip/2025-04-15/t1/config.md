---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through April 15"
  originalSheet: "T1"
  vintageDate: "2025-04-15"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through April 15**
