---
figureType: table
spec:
  title: "Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy as of July 30"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "F2_T2"
  vintageDate: "2025-07-30"
---

**Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy as of July 30**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
