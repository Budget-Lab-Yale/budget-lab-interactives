---
figureType: table
spec:
  title: "Figure 6. Long-Run Change in Real GDP Level from 2025 Tariffs to Date"
  subtitle: "U.S. tariffs implemented as of July 30. Percentage point change"
  source: "GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "FTROW = countries with a comprehensive free trade agreement with the US. ROW = all other countries."
  originalSheet: "F6"
  vintageDate: "2025-07-30"
---

**Figure 6. Long-Run Change in Real GDP Level from 2025 Tariffs to Date**

U.S. tariffs implemented as of July 30. Percentage point change

_Notes: FTROW = countries with a comprehensive free trade agreement with the US. ROW = all other countries._

_Source: GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
