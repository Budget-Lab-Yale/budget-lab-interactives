---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs as of July 30"
  originalSheet: "T1"
  vintageDate: "2025-07-30"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs as of July 30**
