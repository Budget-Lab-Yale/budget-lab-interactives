---
figureType: table
spec:
  title: "Figure 7. Short-Run Distributional Effects of 2025 Tariffs"
  subtitle: "As of July 30. By household income decile"
  source: "GTAP v7, Census, BLS, BEA, The Budget Lab analysis."
  originalSheet: "F7"
  vintageDate: "2025-07-30"
---

**Figure 7. Short-Run Distributional Effects of 2025 Tariffs**

As of July 30. By household income decile

_Source: GTAP v7, Census, BLS, BEA, The Budget Lab analysis._
