---
figureType: table
spec:
  title: "Table 2/Figure 2. Average Effective US Tariff Rate, New 2025 Policy Through July 22"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "T2,F2"
  vintageDate: "2025-07-22"
---

**Table 2/Figure 2. Average Effective US Tariff Rate, New 2025 Policy Through July 22**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
