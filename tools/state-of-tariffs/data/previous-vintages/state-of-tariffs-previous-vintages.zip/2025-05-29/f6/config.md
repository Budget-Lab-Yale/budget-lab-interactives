---
figureType: table
spec:
  title: "Figure 6. Short-Run Distributional Effects of 2025 Tariffs"
  subtitle: "Through May 28. By household income decile"
  source: "GTAP v7, Census, BLS, BEA, The Budget Lab analysis."
  originalSheet: "F6"
  vintageDate: "2025-05-29"
---

**Figure 6. Short-Run Distributional Effects of 2025 Tariffs**

Through May 28. By household income decile

_Source: GTAP v7, Census, BLS, BEA, The Budget Lab analysis._
