---
figureType: table
spec:
  title: "Figure 4. Change in Long-Run Real US GDP by Sector from 2025 Tariffs"
  subtitle: "Effect of all 2025 US tariffs through May 28, plus add'l 40% EU 'reciprocal' tariff, foriegn retaliation & deals Percentage Points"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "F4"
  vintageDate: "2025-05-29"
---

**Figure 4. Change in Long-Run Real US GDP by Sector from 2025 Tariffs**

Effect of all 2025 US tariffs through May 28, plus add'l 40% EU 'reciprocal' tariff, foriegn retaliation & deals Percentage Points

_Source: GTAP v7, The Budget Lab analysis._
