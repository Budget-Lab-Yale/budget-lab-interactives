---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through May 28"
  originalSheet: "T1"
  vintageDate: "2025-05-29"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through May 28**
