---
figureType: table
spec:
  title: "Figure 5. Long-Run Change in Real GDP Level from 2025 Tariffs to Date"
  subtitle: "U.S. tariffs implemented through June 1. Percentage point change"
  source: "GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "FTROW = countries with a comprehensive free trade agreement with the US. ROW = all other countries."
  originalSheet: "F5"
  vintageDate: "2025-06-01"
---

**Figure 5. Long-Run Change in Real GDP Level from 2025 Tariffs to Date**

U.S. tariffs implemented through June 1. Percentage point change

_Notes: FTROW = countries with a comprehensive free trade agreement with the US. ROW = all other countries._

_Source: GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
