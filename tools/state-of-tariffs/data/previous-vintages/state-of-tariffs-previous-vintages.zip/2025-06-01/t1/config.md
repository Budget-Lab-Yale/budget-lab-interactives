---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through June 1"
  originalSheet: "T1"
  vintageDate: "2025-06-01"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs Through June 1**
