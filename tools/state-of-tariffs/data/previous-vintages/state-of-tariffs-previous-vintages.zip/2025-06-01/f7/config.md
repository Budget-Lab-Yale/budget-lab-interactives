---
figureType: table
spec:
  title: "Figure 7. Commodity Price Effects from 2025 Tariffs Through June 1"
  subtitle: "Percent change to price level"
  source: "GTAP v7 [Corong et al (2017)], The Budget Lab analysis."
  notes: "'nec' = 'Not elsewhere classified.'"
  originalSheet: "F7"
  vintageDate: "2025-06-01"
---

**Figure 7. Commodity Price Effects from 2025 Tariffs Through June 1**

Percent change to price level

_Notes: "nec" = "Not elsewhere classified."_

_Source: GTAP v7 [Corong et al (2017)], The Budget Lab analysis._
