---
figureType: table
spec:
  title: "Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy through August 6"
  subtitle: "Pre- and post-substitution"
  source: "GTAP v7, The Budget Lab analysis."
  originalSheet: "T2,F1"
  vintageDate: "2025-08-07"
---

**Table 2/Figure 1. Average Effective US Tariff Rate, New 2025 Policy through August 6**

Pre- and post-substitution

_Source: GTAP v7, The Budget Lab analysis._
