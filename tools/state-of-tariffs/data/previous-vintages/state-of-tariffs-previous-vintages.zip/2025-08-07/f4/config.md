---
figureType: table
spec:
  title: "Figure 4. US Real GDP Level Effects of 2025 Tariffs to Date"
  subtitle: "US tariffs implemented through August 6. Percentage point change against baseline"
  source: "Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis."
  originalSheet: "F4"
  vintageDate: "2025-08-07"
---

**Figure 4. US Real GDP Level Effects of 2025 Tariffs to Date**

US tariffs implemented through August 6. Percentage point change against baseline

_Source: Historical Statistics of the United States Ea424-434, Monthly Treasury Statement, Bureau of Economic Analysis, The Budget Lab analysis._
