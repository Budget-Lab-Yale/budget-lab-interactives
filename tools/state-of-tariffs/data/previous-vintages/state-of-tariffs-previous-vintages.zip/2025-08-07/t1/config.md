---
figureType: table
spec:
  title: "Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs through August 6"
  originalSheet: "T1"
  vintageDate: "2025-08-07"
---

**Table 1. Summary Economic & Fiscal Effects of 2025 Tariffs through August 6**
