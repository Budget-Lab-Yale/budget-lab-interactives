---
figureType: table
spec:
  title: "Figure 3. US Average Effective Tariff Rate Since January 1, 2025"
  subtitle: "Policy through August 6, Pre-Substitution, Percent of goods imports"
  source: "The Budget Lab analysis."
  originalSheet: "F3"
  vintageDate: "2025-08-07"
---

**Figure 3. US Average Effective Tariff Rate Since January 1, 2025**

Policy through August 6, Pre-Substitution, Percent of goods imports

_Source: The Budget Lab analysis._
